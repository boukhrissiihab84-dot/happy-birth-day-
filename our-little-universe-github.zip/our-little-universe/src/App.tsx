import { useCallback, useEffect, useRef, useState } from 'react';
import { content } from './config/content';
import {
  ArrowDown, ArrowLeft, ArrowRight, AudioLines, ChevronDown, Disc3,
  Heart, Maximize, Music2, Pause, Play, Sparkles, Volume2, VolumeX, X,
} from 'lucide-react';

type Memory = (typeof content.gallery)[number];
const assetPath = (path: string) => path.startsWith('/') ? `${import.meta.env.BASE_URL}${path.slice(1)}` : path;

function MusicPlayer({ unlocked }: { unlocked: boolean }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.72);
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);
  useEffect(() => {
    const audio = audioRef.current;
    if (!unlocked || !audio || !content.music.src) return;
    audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
  }, [unlocked]);
  const toggle = async () => {
    const audio = audioRef.current;
    if (!audio || !content.music.src) return;
    if (playing) { audio.pause(); setPlaying(false); }
    else {
      try { await audio.play(); setPlaying(true); } catch { setPlaying(false); }
    }
  };
  return (
    <aside className="music-dock" aria-label="Persistent music player" data-testid="music-player">
      {content.music.src && <audio ref={audioRef} src={assetPath(content.music.src)} loop onTimeUpdate={() => setTime(audioRef.current?.currentTime ?? 0)} onLoadedMetadata={() => setDuration(audioRef.current?.duration ?? 0)} onEnded={() => setPlaying(false)} />}
      <div className={`vinyl ${playing ? 'vinyl-spin' : ''}`} style={{ width: 34, height: 34, borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'radial-gradient(circle,#d6b784 0 3px,#3b232b 4px 11px,#211318 12px 100%)', border: '1px solid #76515a' }} aria-hidden="true"><Disc3 size={17} color="#d8b784" /></div>
      <span className={`music-visualizer ${playing ? 'is-playing' : ''}`} aria-hidden="true">
        {Array.from({ length: 5 }, (_, index) => <i key={index} />)}
      </span>
      <div style={{ minWidth: 82, maxWidth: 120 }}>
        <div style={{ fontSize: '.66rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{content.music.title}</div>
        <div style={{ color: '#af9b96', fontSize: '.58rem' }}>{content.music.src ? content.music.artist : 'Add a track in content.ts'}</div>
      </div>
      <button type="button" aria-label={playing ? 'Pause music' : 'Play music'} title={content.music.src ? undefined : 'Add a track in src/config/content.ts'} onClick={toggle} disabled={!unlocked || !content.music.src} data-testid="toggle-music" style={{ border: 0, background: 'none', cursor: content.music.src ? 'pointer' : 'not-allowed', opacity: content.music.src ? 1 : .45, padding: 5 }}>
        {playing ? <Pause size={16} /> : <Play size={16} />}
      </button>
      {content.music.src ? <input aria-label="Music progress" type="range" min="0" max={duration || 0} value={Math.min(time, duration || 0)} onChange={(event) => { if (audioRef.current) audioRef.current.currentTime = Number(event.target.value); }} /> : <AudioLines size={15} color="#a88380" aria-hidden="true" />}
      <label title="Volume" style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        {volume === 0 ? <VolumeX size={15} /> : <Volume2 size={15} />}
        <input aria-label="Music volume" type="range" min="0" max="1" step=".01" value={volume} onChange={(event) => setVolume(Number(event.target.value))} />
      </label>
    </aside>
  );
}

function VideoPlayer({ video, onError }: { video: (typeof content.videos)[number]; onError: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [muted, setMuted] = useState(false);

  const togglePlayback = async () => {
    const player = videoRef.current;
    if (!player) return;
    if (player.paused) {
      try {
        await player.play();
        setPlaying(true);
      } catch {
        setPlaying(false);
        onError();
      }
    } else {
      player.pause();
      setPlaying(false);
    }
  };

  const toggleFullscreen = async () => {
    if (document.fullscreenElement) {
      await document.exitFullscreen().catch(() => undefined);
      return;
    }
    if (playerRef.current?.requestFullscreen) {
      await playerRef.current.requestFullscreen().catch(() => undefined);
      return;
    }
    const safariVideo = videoRef.current as (HTMLVideoElement & { webkitEnterFullscreen?: () => void }) | null;
    safariVideo?.webkitEnterFullscreen?.();
  };

  return <div className="video-player" ref={playerRef}>
    <div className="video-stage">
      <video
        ref={videoRef}
        src={assetPath(video.src)}
        playsInline
        preload="metadata"
        aria-label={video.title}
        onClick={togglePlayback}
        onTimeUpdate={() => setTime(videoRef.current?.currentTime ?? 0)}
        onLoadedMetadata={() => {
          const player = videoRef.current;
          if (!player) return;
          setDuration(player.duration);
          player.volume = volume;
          player.muted = muted;
        }}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => setPlaying(false)}
        onError={onError}
      />
      {!playing && <button type="button" className="video-play-overlay" onClick={togglePlayback} aria-label={`Play ${video.title}`}><Play size={27} fill="currentColor" /></button>}
    </div>
    <div className="video-controls" aria-label={`${video.title} controls`}>
      <button type="button" onClick={togglePlayback} aria-label={playing ? 'Pause video' : 'Play video'}>{playing ? <Pause size={17} /> : <Play size={17} />}</button>
      <input aria-label="Video progress" type="range" min="0" max={duration || 0} value={Math.min(time, duration || 0)} onChange={(event) => {
        const nextTime = Number(event.target.value);
        if (videoRef.current) videoRef.current.currentTime = nextTime;
        setTime(nextTime);
      }} />
      <label className="video-volume">
        <button type="button" onClick={() => {
          const nextMuted = !muted;
          setMuted(nextMuted);
          if (videoRef.current) videoRef.current.muted = nextMuted;
        }} aria-label={muted ? 'Unmute video' : 'Mute video'}>{muted ? <VolumeX size={17} /> : <Volume2 size={17} />}</button>
        <input aria-label="Video volume" type="range" min="0" max="1" step=".01" value={volume} onChange={(event) => {
          const nextVolume = Number(event.target.value);
          setVolume(nextVolume);
          if (videoRef.current) {
            videoRef.current.volume = nextVolume;
            videoRef.current.muted = nextVolume === 0;
            setMuted(nextVolume === 0);
          }
        }} />
      </label>
      <button type="button" onClick={toggleFullscreen} aria-label="View video fullscreen"><Maximize size={17} /></button>
    </div>
  </div>;
}

function PhotoViewer({ memory, index, onClose, onMove }: { memory: Memory; index: number; onClose: () => void; onMove: (delta: number) => void }) {
  const touchStart = useRef<number | null>(null);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
      if (event.key === 'ArrowRight') onMove(1);
      if (event.key === 'ArrowLeft') onMove(-1);
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [onClose, onMove]);
  return <div className="gallery-viewer" role="dialog" aria-modal="true" aria-label={`Memory ${index + 1} of ${content.gallery.length}`}
    onTouchStart={(event) => { touchStart.current = event.touches[0]?.clientX ?? null; }}
    onTouchEnd={(event) => { if (touchStart.current !== null) { const delta = (event.changedTouches[0]?.clientX ?? touchStart.current) - touchStart.current; if (Math.abs(delta) > 48) onMove(delta < 0 ? 1 : -1); touchStart.current = null; } }}>
    <button type="button" className="viewer-control viewer-close" aria-label="Close photo viewer" onClick={onClose}><X /></button>
    <button type="button" className="viewer-control viewer-prev" aria-label="Previous photo" onClick={() => onMove(-1)}><ArrowLeft /></button>
    <div style={{ display: 'grid', justifyItems: 'center', gap: 14 }}>
      {memory.src ? <img className="viewer-image" src={assetPath(memory.src)} alt={memory.caption} /> : <div className="viewer-placeholder"><div><Sparkles size={25} color="#d6b784" /><p className="serif" style={{ fontSize: '1.35rem' }}>Your photograph will live here</p><span style={{ fontSize: '.75rem', color: '#bca9a4' }}>Add an image path in src/config/content.ts</span></div></div>}
      <div style={{ color: '#d7c5bc', font: 'italic 1.2rem var(--app-font-serif)' }}>{memory.caption}{memory.date && ` · ${memory.date}`}</div>
      <div className="eyebrow">{String(index + 1).padStart(2, '0')} / {String(content.gallery.length).padStart(2, '0')}</div>
    </div>
    <button type="button" className="viewer-control viewer-next" aria-label="Next photo" onClick={() => onMove(1)}><ArrowRight /></button>
  </div>;
}

function App() {
  const [opened, setOpened] = useState(false);
  const [viewerIndex, setViewerIndex] = useState<number | null>(null);
  const [candles, setCandles] = useState([true, true, true, true, true]);
  const [celebrated, setCelebrated] = useState(false);
  const [letterOpen, setLetterOpen] = useState(false);
  const [typed, setTyped] = useState('');
  const [finalOpen, setFinalOpen] = useState(false);
  const [videoErrors, setVideoErrors] = useState<string[]>([]);

  useEffect(() => {
    if (!opened) return;
    const sections = Array.from(document.querySelectorAll<HTMLElement>('.scroll-reveal'));
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) {
      sections.forEach((section) => section.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -36px 0px' });
    sections.forEach((section) => {
      section.classList.add('reveal-ready');
      observer.observe(section);
    });
    return () => observer.disconnect();
  }, [opened]);

  useEffect(() => {
    if (!letterOpen) return;
    let at = 0;
    const timer = window.setInterval(() => {
      at += 2;
      setTyped(content.letter.slice(0, at));
      if (at >= content.letter.length) window.clearInterval(timer);
    }, 32);
    return () => window.clearInterval(timer);
  }, [letterOpen]);
  const closeViewer = useCallback(() => setViewerIndex(null), []);
  const moveViewer = useCallback((delta: number) => {
    setViewerIndex((current) => current === null ? null : (current + delta + content.gallery.length) % content.gallery.length);
  }, []);
  const openExperience = () => {
    setOpened(true);
    window.setTimeout(() => document.getElementById('beginning')?.scrollIntoView({ behavior: 'smooth' }), 100);
  };
  const extinguish = (index: number) => {
    const next = candles.map((lit, candle) => candle === index ? false : lit);
    setCandles(next);
    if (!next.some(Boolean)) setCelebrated(true);
  };
  const resetCake = () => { setCandles([true, true, true, true, true]); setCelebrated(false); };

  if (!opened) return <main className="grain" style={{ minHeight: '100dvh', overflow: 'hidden', position: 'relative', display: 'grid', placeItems: 'center', background: 'radial-gradient(ellipse at 50% 40%,#542c3b 0%,#321b25 36%,#1d1218 78%)' }}>
    <div aria-hidden="true" style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 112%,rgba(187,105,120,.24),transparent 50%)' }}>
      {Array.from({ length: 34 }, (_, i) => <i key={i} className="star" style={{ position: 'absolute', left: `${(i * 47 + 7) % 100}%`, top: `${(i * 31 + 5) % 94}%`, width: i % 6 === 0 ? 3 : 2, height: i % 6 === 0 ? 3 : 2, borderRadius: '50%', background: '#e9c994', opacity: .28 + (i % 5) * .1, animationDelay: `${i * -.37}s` }} />)}
    </div>
    <div className="petal-field" aria-hidden="true">{Array.from({ length: 9 }, (_, i) => <i className="rose-petal" key={i} style={{ left: `${(i * 19 + 7) % 100}%`, animationDelay: `${i * -2.3}s`, animationDuration: `${13 + (i % 4) * 2}s` }} />)}</div>
    <div className="reveal" style={{ position: 'relative', zIndex: 1, maxWidth: 790, width: '100%', textAlign: 'center', padding: '30px 22px' }}>
      <div className="eyebrow" style={{ marginBottom: 29 }}>A little universe, made just for you</div>
      <div style={{ width: 1, height: 72, margin: '0 auto 30px', background: 'linear-gradient(transparent,#d6b784,transparent)' }} />
      <p style={{ color: '#d8b7ad', font: 'italic 1.15rem var(--app-font-serif)', letterSpacing: '.04em' }}>{content.intro}</p>
      <h1 className="serif" style={{ fontSize: 'clamp(3.7rem,12vw,8.2rem)', lineHeight: '.85', fontWeight: 400, margin: '20px 0 15px', color: '#f2e4d7' }}>{content.greeting}<br /><em style={{ color: '#d8aeb0', fontWeight: 400 }}>{content.name}</em></h1>
      <p className="eyebrow" style={{ marginTop: 24 }}>{content.birthdayDate}</p>
      <button type="button" onClick={openExperience} data-testid="open-surprise" style={{ marginTop: 40, padding: '15px 25px', border: '1px solid #d6b784', background: 'rgba(214,183,132,.08)', color: '#ead6bc', textTransform: 'uppercase', letterSpacing: '.2em', fontSize: '.67rem', cursor: 'pointer', transition: 'background .3s, transform .3s' }} onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(214,183,132,.17)'; e.currentTarget.style.transform = 'translateY(-2px)'; }} onMouseLeave={(e) => { e.currentTarget.style.background = 'rgba(214,183,132,.08)'; e.currentTarget.style.transform = 'translateY(0)'; }}>
        Open your surprise <ArrowRight size={14} style={{ verticalAlign: 'middle', marginLeft: 10 }} />
      </button>
      <p style={{ fontSize: '.68rem', color: '#a88e8e', marginTop: 20 }}>Your music, if added, begins when you open the gift.</p>
    </div>
    <div style={{ position: 'absolute', bottom: 26, left: 0, right: 0, textAlign: 'center', color: '#987f82', fontSize: '.6rem', letterSpacing: '.18em' }}>MADE OF MOMENTS · MADE FOR YOU</div>
  </main>;

  return <main className="grain" style={{ minHeight: '100dvh', overflowX: 'hidden' }}>
    <header className="site-header">
      <a href="#beginning" aria-label="Back to beginning" style={{ textDecoration: 'none', color: '#e8d6c5', display: 'flex', alignItems: 'center', gap: 8 }}><span style={{ width: 24, height: 24, border: '1px solid #a9837b', borderRadius: '50%', display: 'grid', placeItems: 'center' }}><Heart size={12} /></span><span className="serif" style={{ fontSize: '1.15rem' }}>our little universe</span></a>
      <nav className="site-nav" aria-label="Story sections">
        <a href="#memories">Memories</a><a href="#story">Our story</a><a href="#letter">A letter</a>
      </nav>
    </header>
    <section id="beginning" style={{ minHeight: 'min(760px, calc(100dvh - 64px))', position: 'relative', display: 'grid', alignItems: 'center', background: 'radial-gradient(ellipse at 72% 46%,rgba(124,65,78,.38),transparent 42%),linear-gradient(110deg,#29171e,#321c26 57%,#1e1319)', padding: '80px clamp(24px,10vw,150px)' }}>
      <div style={{ position: 'absolute', right: '11%', top: '15%', width: 'min(36vw,420px)', aspectRatio: '1', border: '1px solid rgba(214,183,132,.17)', borderRadius: '50%', boxShadow: '0 0 90px rgba(183,110,122,.1),inset 0 0 80px rgba(214,183,132,.04)' }} />
      <div style={{ position: 'relative', maxWidth: 680 }} className="reveal">
        <div className="eyebrow">Chapter one · the day is yours</div>
        <h2 className="serif" style={{ fontWeight: 400, fontSize: 'clamp(3.8rem,10vw,8rem)', lineHeight: '.83', margin: '27px 0' }}>{content.greeting}<br /><span style={{ color: '#d7aeb0', fontStyle: 'italic' }}>{content.name}</span></h2>
        <p style={{ maxWidth: 410, lineHeight: 1.8, color: '#c4aeaa', font: 'italic 1.2rem var(--app-font-serif)' }}>{content.intro}</p>
        <a href="#memories" style={{ display: 'inline-flex', alignItems: 'center', gap: 12, marginTop: 32, textDecoration: 'none', color: '#dec59d', fontSize: '.7rem', letterSpacing: '.14em', textTransform: 'uppercase' }}>Step into our memories <ArrowDown size={15} /></a>
      </div>
      <div className="eyebrow" style={{ position: 'absolute', bottom: 30, right: '9%', color: '#9e7d7e' }}>{content.birthdayDate}</div>
    </section>

    <section id="memories" className="section scroll-reveal">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', alignItems: 'end', gap: 20, marginBottom: 38 }}>
        <div><div className="eyebrow">Collected, kept, remembered</div><h2 className="section-heading serif">Little moments.<br /><i style={{ color: '#d7aeb0' }}>Whole worlds.</i></h2></div>
        <p style={{ maxWidth: 230, color: '#af9d98', font: 'italic 1rem var(--app-font-serif)', lineHeight: 1.6, marginBottom: 8 }}>A place for the photographs that make a story feel like yours.</p>
      </div>
      <div className="memory-grid">
        {content.gallery.map((memory, index) => <div className="memory-tile" key={memory.id}>
          <button type="button" className="memory-button" onClick={() => setViewerIndex(index)} aria-label={`Open memory ${index + 1}${memory.caption ? `: ${memory.caption}` : ''}`} data-testid={`open-memory-${index + 1}`}>
            {memory.src ? <img src={assetPath(memory.src)} alt={memory.caption || `Memory ${index + 1}`} loading="lazy" /> : <div className="memory-placeholder"><span className="eyebrow">Memory {String(index + 1).padStart(2, '0')}</span><Sparkles size={17} color="#b98e83" /><span style={{ font: 'italic 1.05rem var(--app-font-serif)' }}>Your photo goes here</span></div>}
            <div className="photo-caption">{memory.caption}{memory.date && <span style={{ color: '#a88b88', fontSize: '.78rem' }}> · {memory.date}</span>}</div>
          </button>
        </div>)}
      </div>
    </section>

    <section id="films" className="section scroll-reveal" style={{ paddingTop: 70, background: 'linear-gradient(180deg,transparent,rgba(70,36,47,.22),transparent)' }}>
      <div className="eyebrow">The moving pictures</div><h2 className="section-heading serif">A little <i style={{ color: '#d7aeb0' }}>in motion.</i></h2>
      <p style={{ color: '#b6a19c', maxWidth: 490, lineHeight: 1.7 }}>Small films deserve a place in the story too. Add your own videos in the content file; no stock footage is used here.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,320px),1fr))', gap: 18, marginTop: 34 }}>
        {content.videos.map((video) => <article className="video-card" key={video.id}>
          {video.src ? <VideoPlayer video={video} onError={() => setVideoErrors((errors) => errors.includes(video.id) ? errors : [...errors, video.id])} /> :
            <div style={{ minHeight: 240, display: 'grid', placeItems: 'center', textAlign: 'center', background: 'radial-gradient(ellipse,#49303a,#25171d)', padding: 24 }}><div><Play size={25} color="#d6b784" /><p className="serif" style={{ fontSize: '1.4rem', marginBottom: 6 }}>{video.title}</p><span style={{ color: '#b6a09c', fontSize: '.75rem' }}>Add a video path in src/config/content.ts</span></div></div>}
          {videoErrors.includes(video.id) && <p role="status" style={{ color: '#e8b6b2', fontSize: '.75rem', padding: '0 12px' }}>This video could not be loaded. Check the file path.</p>}
          <div style={{ padding: '12px 4px 5px' }}><div className="serif" style={{ fontSize: '1.25rem' }}>{video.title}</div><div style={{ color: '#af9b96', fontSize: '.75rem', marginTop: 4 }}>{video.caption}</div></div>
        </article>)}
      </div>
    </section>

    <section id="story" className="section scroll-reveal">
      <div style={{ textAlign: 'center' }}><div className="eyebrow">A story still being written</div><h2 className="section-heading serif">The chapters <i style={{ color: '#d7aeb0' }}>we keep.</i></h2><p style={{ color: '#ae9995', maxWidth: 450, margin: '0 auto' }}>Every date and line below is an editable placeholder. Add only the moments that are truly yours.</p></div>
      <div className="timeline">{content.timeline.map((item, i) => <article className="timeline-item" key={item.id}>
        <span className="timeline-dot" aria-hidden="true" />
        <div className="eyebrow">{item.date || `Chapter ${i + 1}`}</div><h3 className="serif" style={{ fontSize: '1.8rem', fontWeight: 400, margin: '7px 0' }}>{item.title}</h3>
        <p style={{ color: '#b9a49e', lineHeight: 1.7, maxWidth: 570, margin: 0 }}>{item.description}</p>
        {item.photo && <img src={assetPath(item.photo)} alt="" loading="lazy" style={{ width: 'min(100%,380px)', maxHeight: 260, objectFit: 'contain', marginTop: 16, border: '1px solid #664650' }} />}
      </article>)}</div>
    </section>

    <section id="song" className="section scroll-reveal" style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(180px,280px)', alignItems: 'center', gap: 35, borderBlock: '1px solid rgba(224,196,170,.12)', background: 'rgba(84,43,57,.12)' }}>
      <div><div className="eyebrow">Side A · one song, one feeling</div><h2 className="section-heading serif">The soundtrack<br /><i style={{ color: '#d7aeb0' }}>to this universe.</i></h2><p style={{ color: '#b7a29d', lineHeight: 1.7, maxWidth: 440 }}>Add an MP3 you have permission to share. The player stays with you while you wander through the story.</p><div style={{ display: 'flex', alignItems: 'center', gap: 9, color: '#d6b784', fontSize: '.8rem', marginTop: 22 }}><Music2 size={16} /> {content.music.src ? `${content.music.title} — ${content.music.artist}` : 'No track added yet. Add one in src/config/content.ts.'}</div></div>
      <div style={{ justifySelf: 'center', position: 'relative', width: 'min(53vw,230px)', aspectRatio: '1', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'repeating-radial-gradient(circle,#24161b 0 4px,#39242b 5px 6px,#211419 7px 9px)', border: '1px solid #73505b', boxShadow: '0 18px 40px #12090e80' }}><div style={{ width: '35%', height: '35%', borderRadius: '50%', background: 'radial-gradient(circle,#d6b784,#854e59 65%,#3d2630)', display: 'grid', placeItems: 'center', color: '#2e1b20' }}><Disc3 size={35} /></div><span className="eyebrow" style={{ position: 'absolute', top: '18%', color: '#c9a880', fontSize: '.48rem' }}>OUR LITTLE UNIVERSE</span></div>
    </section>

    <section id="reasons" className="section scroll-reveal">
      <div className="eyebrow">A few things, in no particular order</div><h2 className="section-heading serif">Reasons, <i style={{ color: '#d7aeb0' }}>as many as you like.</i></h2>
      <p style={{ color: '#ae9995', maxWidth: 500, lineHeight: 1.7 }}>These are gentle placeholders, not invented personal reasons. Replace every line with something you mean.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,220px),1fr))', gap: 13, marginTop: 35 }}>
        {content.reasons.map((reason, i) => <article className="reason-card" key={`${i}-${reason}`}><span className="eyebrow">No. {String(i + 1).padStart(2, '0')}</span><p className="serif" style={{ fontSize: '1.48rem', lineHeight: 1.25, margin: '20px 0 6px' }}>{reason}</p><Heart size={15} color="#bb8586" /></article>)}
      </div>
    </section>

    <section id="cake" className="section scroll-reveal" style={{ textAlign: 'center', background: 'radial-gradient(ellipse at 50% 100%,rgba(122,62,77,.26),transparent 60%)' }}>
      <div className="eyebrow">Make a wish, whenever you're ready</div><h2 className="section-heading serif">A candle for <i style={{ color: '#d7aeb0' }}>each wish.</i></h2>
      <p style={{ color: '#ae9995' }}>Tap each flame to make it glow away. When they are all out, the celebration begins.</p>
      <div className="cake" aria-label={`Birthday cake with ${candles.filter(Boolean).length} candles still lit`}>
        <div className="candles">{candles.map((lit, i) => <button type="button" key={i} aria-label={`${lit ? 'Extinguish' : 'Relight'} candle ${i + 1}`} aria-pressed={!lit} className={`candle ${lit ? '' : 'out'}`} onClick={() => lit ? extinguish(i) : (setCandles((old) => old.map((value, idx) => idx === i ? true : value)), setCelebrated(false))} data-testid={`candle-${i + 1}`}>{lit && <span className="cake-flame" />}</button>)}</div>
        <div className="cake-tier top" /><div className="cake-tier" />
      </div>
      {celebrated ? <div className="reveal" role="status" style={{ marginTop: 30 }}><h3 className="serif" style={{ fontSize: '2rem', fontWeight: 400, color: '#e4c996' }}>A wish, sent out into the universe.</h3><p style={{ color: '#bfa9a0' }}>Happy birthday, {content.name}.</p><button type="button" onClick={resetCake} style={{ border: '1px solid #a77d7d', background: 'transparent', padding: '10px 17px', cursor: 'pointer', marginTop: 8 }}>Light the candles again</button></div> : <p style={{ marginTop: 28, color: '#a78e8d', fontSize: '.7rem' }}>{candles.filter(Boolean).length} candle{candles.filter(Boolean).length === 1 ? '' : 's'} still glowing</p>}
      {celebrated && <div className="confetti-wrap" aria-hidden="true">{Array.from({ length: 50 }, (_, i) => <i className="confetti-piece" key={i} style={{ position: 'absolute', top: -16, left: `${(i * 37) % 100}%`, width: i % 3 === 0 ? 7 : 4, height: i % 3 === 0 ? 12 : 7, background: ['#d6b784','#c87988','#efc8b8','#9b6370'][i % 4], animationDelay: `${(i % 13) * .11}s` }} />)}</div>}
    </section>

    <section id="letter" className="section scroll-reveal" style={{ textAlign: 'center' }}>
      <div className="eyebrow">A note, from the heart</div><h2 className="section-heading serif">Something <i style={{ color: '#d7aeb0' }}>to keep.</i></h2>
      <p style={{ color: '#ad9993' }}>Tap the envelope when you are ready to open it.</p>
      <button type="button" className={`envelope ${letterOpen ? 'open' : ''}`} onClick={() => { setLetterOpen(true); }} aria-expanded={letterOpen} aria-label={letterOpen ? 'Letter opened' : 'Open the letter'} data-testid="open-letter">
        <span className="envelope-flap" /><span className="wax-seal">L</span>
      </button>
      {letterOpen && <article className="letter-paper letter-in" aria-live="polite">
        <div className="eyebrow" style={{ color: '#966b69' }}>A letter for you</div>
        <p className="script" style={{ textAlign: 'left', lineHeight: 1.9, fontSize: 'clamp(1rem,3vw,1.35rem)', minHeight: 90 }}>{typed}<span aria-hidden="true" style={{ opacity: typed.length < content.letter.length ? .55 : 0 }}>▍</span></p>
        <p className="script" style={{ textAlign: 'right', fontSize: '1.4rem', marginTop: 28 }}>{content.signature}</p>
      </article>}
    </section>

    <section id="surprise" className="section scroll-reveal" style={{ minHeight: 470, display: 'grid', placeItems: 'center', textAlign: 'center', background: 'radial-gradient(ellipse at 50% 58%,rgba(138,71,87,.35),transparent 58%)' }}>
      {!finalOpen ? <div><div className="eyebrow">One last little thing</div><h2 className="serif" style={{ fontSize: 'clamp(3rem,8vw,6rem)', fontWeight: 400, margin: '16px 0 28px' }}>Before you go…</h2><button type="button" onClick={() => setFinalOpen(true)} style={{ background: 'transparent', border: '1px solid #d6b784', color: '#e2c99f', padding: '15px 24px', cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '.16em', fontSize: '.67rem' }} data-testid="reveal-final">Reveal the last surprise <ChevronDown size={14} style={{ verticalAlign: 'middle', marginLeft: 8 }} /></button></div> :
        <div className="reveal final-reveal"><div className="final-petals" aria-hidden="true">{Array.from({ length: 7 }, (_, i) => <i className="rose-petal" key={i} style={{ left: `${8 + i * 13}%`, animationDelay: `${-i * 1.8}s` }} />)}</div><Sparkles size={26} color="#d6b784" /><div className="eyebrow" style={{ marginTop: 18 }}>For all the days ahead</div><h2 className="serif" style={{ fontSize: 'clamp(2.5rem,7vw,5.6rem)', fontWeight: 400, maxWidth: 800, lineHeight: .98, color: '#f0dfd0', margin: '22px auto' }}>{content.finalMessage}</h2><p className="script" style={{ color: '#d7aeb0', fontSize: '1.7rem' }}>Happy birthday, {content.name}.</p><button type="button" onClick={() => setFinalOpen(false)} style={{ marginTop: 24, background: 'none', border: 'none', color: '#b59b98', cursor: 'pointer', fontSize: '.75rem', textDecoration: 'underline', textUnderlineOffset: 4 }}>Keep this moment tucked away</button></div>}
    </section>
    <footer className="footer"><span className="serif" style={{ fontSize: '1.3rem', color: '#d6b784' }}>our little universe</span><p>A small gift, made with care.</p></footer>
    {viewerIndex !== null && <PhotoViewer memory={content.gallery[viewerIndex]} index={viewerIndex} onClose={closeViewer} onMove={moveViewer} />}
    <MusicPlayer unlocked={opened} />
  </main>;
}

export default App;
