/**
 * PERSONAL CONTENT — edit this file to make the experience yours.
 * Put original media in public/assets/photos, /videos and /music, then reference
 * it with paths such as /assets/photos/our-photo.jpg. Leave src blank until then.
 * No personal stories or prose are supplied here; replace the neutral prompts.
 */
export const content = {
  name: 'Your person',
  birthdayDate: 'Add birthday date',
  intro: 'A small world, made for one very special person.',
  greeting: 'Happy birthday,',
  gallery: Array.from({ length: 32 }, (_, index) => ({
    id: `memory-${index + 1}`,
    src: '', // Example: '/assets/photos/memory-01.jpg'
    caption: 'Add a caption',
    date: '',
  })),
  videos: [
    { id: 'film-1', src: '', title: 'Add your first film', caption: 'A place for a favorite moving memory.' },
    { id: 'film-2', src: '', title: 'Add another film', caption: 'Replace this placeholder with your own video.' },
  ],
  music: {
    src: '', // Example: '/assets/music/our-song.mp3'
    title: 'A song for this little universe',
    artist: 'Add artist name',
  },
  timeline: [
    { id: 'chapter-1', date: 'Add a date', title: 'Add a chapter title', description: 'Replace this neutral prompt with a memory of your own.', photo: '' },
    { id: 'chapter-2', date: 'Add a date', title: 'Add a chapter title', description: 'Add a detail that belongs to your story.', photo: '' },
    { id: 'chapter-3', date: 'Add a date', title: 'Add a chapter title', description: 'Continue the timeline with a moment you choose.', photo: '' },
  ],
  reasons: [
    'Add a reason that is yours',
    'Write a small thing you adore',
    'Add another personal reason',
    'Keep adding as many as you like',
  ],
  letter: 'Write your own letter here. This is a neutral placeholder, not a personal message. Replace it with words you want to share.',
  signature: 'Your signature',
  finalMessage: 'Replace this line with your own final surprise.',
};
